<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return [
	'title' => esc_html__( 'Event Calendar', 'bdthemes-element-pack' ),
	'required' => true,
	'default_activation' => true,
];
