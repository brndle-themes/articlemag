<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return [
	'title'              => esc_html__( 'Slideshow', 'bdthemes-element-pack' ),
	'required'           => true,
	'default_activation' => true,
];
